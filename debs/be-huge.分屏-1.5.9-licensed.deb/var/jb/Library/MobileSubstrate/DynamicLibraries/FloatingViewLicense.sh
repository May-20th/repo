#!/bin/bash
# floatingView 授权检查包装脚本
# 此脚本在插件加载前执行授权验证

LICENSE_FILE="/var/mobile/Library/Preferences/com.floatingview.license.plist"
LOG_FILE="/var/mobile/Library/Logs/floatingview_license.log"

# 创建日志目录
mkdir -p /var/mobile/Library/Logs

# 记录日志
log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# 获取设备 UDID
get_device_id() {
    if [ -f "/var/lib/lockdown/data_ark.plist" ]; then
        UDID=$(grep -A1 "UniqueDeviceID" /var/lib/lockdown/data_ark.plist | tail -1 | sed 's/.*<string>\(.*\)<\/string>.*/\1/')
        echo "$UDID"
    else
        echo "UNKNOWN"
    fi
}

# 生成激活码
generate_license() {
    local device_id="$1"
    local signature=$(echo -n "$device_id" | openssl dgst -sha256 -hmac "FloatingView_License_2026_Secret_Key_V1" | cut -d' ' -f2 | cut -c1-16 | tr '[:lower:]' '[:upper:]')
    echo "${signature:0:4}-${signature:4:4}-${signature:8:4}-${signature:12:4}"
}

# 验证授权
verify_license() {
    # 检查授权文件
    if [ ! -f "$LICENSE_FILE" ]; then
        log "授权文件不存在"
        return 1
    fi
    
    # 读取激活状态
    local activated=$(grep -A1 "<key>activated</key>" "$LICENSE_FILE" | tail -1 | grep -o "true")
    if [ "$activated" != "true" ]; then
        log "插件未激活"
        return 1
    fi
    
    # 读取激活码和设备 ID
    local license_key=$(grep -A1 "<key>license_key</key>" "$LICENSE_FILE" | tail -1 | sed 's/.*<string>\(.*\)<\/string>.*/\1/')
    local stored_device_id=$(grep -A1 "<key>device_id</key>" "$LICENSE_FILE" | tail -1 | sed 's/.*<string>\(.*\)<\/string>.*/\1/')
    
    # 获取当前设备 ID
    local current_device_id=$(get_device_id)
    
    # 验证设备绑定
    if [ "$stored_device_id" != "$current_device_id" ]; then
        log "设备 ID 不匹配: 存储=$stored_device_id, 当前=$current_device_id"
        return 1
    fi
    
    # 验证激活码
    local expected_key=$(generate_license "$current_device_id")
    local normalized_license=$(echo "$license_key" | tr -d '-' | tr '[:lower:]' '[:upper:]')
    local normalized_expected=$(echo "$expected_key" | tr -d '-' | tr '[:upper:]' '[:upper:]')
    
    if [ "$normalized_license" = "$normalized_expected" ]; then
        log "授权验证成功"
        return 0
    else
        log "激活码验证失败"
        return 1
    fi
}

# 执行验证
log "开始授权验证..."
if verify_license; then
    log "✓ floatingView 授权有效"
    exit 0
else
    log "✗ floatingView 授权验证失败"
    # 注意: 这里返回 0 是为了不阻止系统启动
    # 实际的功能限制应在 dylib 中实现
    exit 0
fi
